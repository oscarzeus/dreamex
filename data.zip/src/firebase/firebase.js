// ...existing code...

// Make sure to export these correctly
export const db = getFirestore(app);
export const auth = getAuth(app);

// ...existing code...
